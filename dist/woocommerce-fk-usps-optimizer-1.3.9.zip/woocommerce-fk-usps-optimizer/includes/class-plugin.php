<?php
/**
 * Main plugin bootstrap class for the FK USPS Optimizer plugin.
 *
 * @package FK_USPS_Optimizer
 */

namespace FK_USPS_Optimizer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-boxpacker-item.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-boxpacker-box.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-settings.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-order-plan-service.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-packing-service.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-shipengine-service.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-shipstation-service.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-test-pricing-service.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-pirateship-export.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-admin-ui.php';
require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-admin-test-ui.php';

/**
 * Main plugin class responsible for bootstrapping all services.
 */
class Plugin {
	/**
	 * Order meta key under which the rendered packing-plan note text is
	 * stored. This is the canonical home for the plan; it is rendered in
	 * the admin "USPS Priority Shipping Plan" metabox and injected into
	 * the `customer_note` field of WooCommerce REST API responses so
	 * PirateShip continues to receive it without the value ever being
	 * persisted in the order's customer-note column.
	 *
	 * @var string
	 */
	const PACKING_NOTE_META_KEY = '_fk_packing_plan_note';

	/**
	 * Legacy opening marker that previous versions wrote into the order's
	 * customer note. Kept only so we can clean any pre-upgrade orders by
	 * stripping the marker block on first re-process. Not written by new
	 * code.
	 *
	 * @var string
	 */
	const PACKING_NOTE_START_MARKER = '<!-- fk-pack-start -->';

	/**
	 * Legacy closing marker (see PACKING_NOTE_START_MARKER).
	 *
	 * @var string
	 */
	const PACKING_NOTE_END_MARKER = '<!-- fk-pack-end -->';

	/**
	 * Shipping-item meta key holding the service code of the rate the customer
	 * selected at checkout.  Written by Shipping_Method::calculate_shipping()
	 * (WooCommerce persists rate meta onto the order's shipping item) and read
	 * by process_order() so the plan matches what the customer paid for.
	 *
	 * @var string
	 */
	const META_SERVICE_CODE = '_fk_usps_optimizer_service_code';

	/**
	 * Shipping-item meta key holding the human-readable service label of the
	 * checkout rate (e.g. "USPS Priority").
	 *
	 * @var string
	 */
	const META_SERVICE_LABEL = '_fk_usps_optimizer_service_label';

	/**
	 * Shipping-item meta key holding the carrier code of the checkout rate
	 * (e.g. 'usps', 'ups').
	 *
	 * @var string
	 */
	const META_CARRIER_CODE = '_fk_usps_optimizer_carrier_code';

	/**
	 * Singleton plugin instance.
	 *
	 * @var Plugin|null
	 */
	protected static $instance;

	/**
	 * Plugin settings instance.
	 *
	 * @var Settings
	 */
	protected $settings;

	/**
	 * Order plan service instance.
	 *
	 * @var Order_Plan_Service
	 */
	protected $order_plan_service;

	/**
	 * Packing service instance.
	 *
	 * @var Packing_Service
	 */
	protected $packing_service;

	/**
	 * ShipEngine service instance.
	 *
	 * @var ShipEngine_Service
	 */
	protected $shipengine_service;

	/**
	 * PirateShip export service instance.
	 *
	 * @var PirateShip_Export
	 */
	protected $export_service;

	/**
	 * ShipStation service instance.
	 *
	 * @var ShipStation_Service
	 */
	protected $shipstation_service;

	/**
	 * Test pricing service instance.
	 *
	 * @var Test_Pricing_Service
	 */
	protected $test_pricing_service;

	/**
	 * Admin test UI instance.
	 *
	 * @var Admin_Test_UI
	 */
	protected $admin_test_ui;

	/**
	 * Bootstrap and return the singleton plugin instance.
	 *
	 * @return Plugin The plugin instance.
	 */
	public static function bootstrap(): Plugin {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor. Instantiates all services and registers the init hook.
	 */
	protected function __construct() {
		$this->settings             = new Settings();
		$this->order_plan_service   = new Order_Plan_Service();
		$this->packing_service      = new Packing_Service( $this->settings );
		$this->shipengine_service   = new ShipEngine_Service( $this->settings );
		$this->shipstation_service  = new ShipStation_Service( $this->settings );
		$this->test_pricing_service = new Test_Pricing_Service( $this->settings, $this->packing_service, $this->shipengine_service, $this->shipstation_service );
		$this->export_service       = new PirateShip_Export( $this->settings, $this->order_plan_service );
		$this->admin_ui             = new Admin_UI( $this->settings, $this->order_plan_service, $this->export_service );
		$this->admin_test_ui        = new Admin_Test_UI( $this->settings, $this->test_pricing_service );

		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Initialise the plugin after WooCommerce is loaded.
	 *
	 * @return void
	 */
	public function init(): void {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$this->settings->register();
		$this->admin_ui->register();
		$this->admin_test_ui->register();
		$this->export_service->register();

		// Register as a WooCommerce shipping method so it appears in shipping zones.
		require_once FK_USPS_OPTIMIZER_PATH . 'includes/class-shipping-method.php';
		add_filter( 'woocommerce_shipping_methods', array( $this, 'register_shipping_method' ) );

		// Append estimated delivery date on its own line in the cart/checkout label.
		add_filter( 'woocommerce_cart_shipping_method_full_label', array( $this, 'append_delivery_date_to_label' ), 10, 2 );

		add_action( 'woocommerce_checkout_order_processed', array( $this, 'process_order' ), 20, 3 );
		add_action( 'wp_ajax_fk_usps_test_connection', array( $this, 'handle_test_connection_ajax' ) );

		// Inject the stored packing-plan text into the `customer_note` field
		// of WooCommerce REST API order responses so PirateShip (and other
		// REST consumers) receive the plan alongside the order. The plan is
		// never written into the order's stored customer-note column, so it
		// cannot leak into customer emails, the My Account page, the admin
		// order screen or invoices.
		add_filter( 'woocommerce_rest_prepare_shop_order_object', array( $this, 'inject_packing_plan_into_rest_response' ), 10, 3 );
	}

	/**
	 * Process an order after checkout to build its shipping plan.
	 *
	 * @param int       $order_id    The order ID.
	 * @param array     $posted_data Posted checkout data.
	 * @param \WC_Order $order       The WooCommerce order object.
	 * @return void
	 */
	public function process_order( $order_id, $posted_data, $order ): void {
		if ( ! $order instanceof \WC_Order ) {
			$order = wc_get_order( $order_id );
		}

		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		if ( ! $order->needs_shipping_address() ) {
			return;
		}

		// The service the customer actually selected (and paid for) at
		// checkout, when it was one of our optimized rates.
		$chosen         = $this->get_chosen_shipping_info( $order );
		$chosen_service = $chosen['service_code'];

		$plan = array(
			'created_at'          => current_time( 'mysql', true ),
			'total_package_count' => 0,
			'total_rate_amount'   => 0,
			'currency'            => 'USD',
			'packages'            => array(),
			'pirateship_rows'     => array(),
			'warnings'            => array(),
		);

		try {
			$packed_packages = $this->packing_service->pack_order( $order );

			if ( empty( $packed_packages ) ) {
				$plan['warnings'][] = __( 'No shippable items were found for packing.', 'fk-usps-optimizer' );
				$this->order_plan_service->save( $order, $plan );
				return;
			}

			$carrier_services = $this->get_carrier_services();

			foreach ( $packed_packages as $index => $package ) {
				// Prefer the service the customer paid for; never mix carriers
				// or services unless the chosen one cannot be rated.
				$best_plan = $this->find_best_plan( $carrier_services, $order, $package, $index + 1, $chosen_service );

				if ( empty( $best_plan ) && '' !== $chosen_service ) {
					$plan['warnings'][] = sprintf(
						/* translators: 1: selected service code, 2: package number. */
						__( 'The selected service "%1$s" could not be rated for package %2$d; falling back to the cheapest available option.', 'fk-usps-optimizer' ),
						$chosen_service,
						$index + 1
					);
					$best_plan = $this->find_best_plan( $carrier_services, $order, $package, $index + 1, '' );
				}

				if ( empty( $best_plan ) ) {
					$plan['warnings'][] = sprintf(
						/* translators: %d package number. */
						__( 'Unable to produce a shipping plan for package %d.', 'fk-usps-optimizer' ),
						$index + 1
					);
					continue;
				}

				$plan['packages'][]         = $best_plan;
				$plan['total_rate_amount'] += (float) $best_plan['rate_amount'];
				$plan['currency']           = $best_plan['currency'];
				$plan['pirateship_rows'][]  = $this->export_service->build_row( $order, $best_plan );
			}

			$plan['total_package_count'] = count( $plan['packages'] );

			if ( 0 === $plan['total_package_count'] ) {
				$plan['warnings'][] = __( 'All rate-shopping attempts failed. Review carrier API configuration and box setup.', 'fk-usps-optimizer' );
			}
		} catch ( \Throwable $throwable ) {
			$plan['warnings'][] = $throwable->getMessage();
			$this->log(
				'Order planning failed',
				array(
					'order_id' => $order->get_id(),
					'error'    => $throwable->getMessage(),
				)
			);
		}

		// Reconcile the plan with what the customer paid.  Only meaningful when
		// the order shipped via one of our rates.
		if ( $chosen['is_optimizer_method'] ) {
			if ( '' === $chosen_service ) {
				$plan['warnings'][] = __( 'The exact service the customer selected at checkout could not be determined; the plan below shows the cheapest available option.', 'fk-usps-optimizer' );
			} elseif ( $plan['total_package_count'] > 0 ) {
				$paid_total = (float) $order->get_shipping_total();

				if ( abs( $plan['total_rate_amount'] - $paid_total ) >= 0.01 ) {
					$plan['warnings'][] = sprintf(
						/* translators: 1: planned shipping total, 2: amount the customer paid. */
						__( 'The planned shipping total (%1$s) does not match the amount the customer paid (%2$s). Verify the service before buying labels.', 'fk-usps-optimizer' ),
						number_format( $plan['total_rate_amount'], 2 ),
						number_format( $paid_total, 2 )
					);
				}
			}
		}

		$this->order_plan_service->save( $order, $plan );

		if ( $this->settings->is_add_package_note_enabled() && ! empty( $plan['packages'] ) ) {
			$order->add_order_note( $this->build_package_note( $plan ) );
		}

		if ( $this->settings->is_add_packing_to_customer_note_enabled() && ! empty( $plan['packages'] ) ) {
			$this->store_packing_plan_note( $order, $plan );
		}

		// Email the packing plan + PirateShip CSV to the configured
		// recipients (if any) so shipping staff can import the CSV
		// directly into PirateShip without first opening the order.
		if ( ! empty( $plan['packages'] ) && ! empty( $this->settings->get_pirateship_notification_emails() ) ) {
			try {
				$this->export_service->send_order_notification( $order, $plan );
			} catch ( \Throwable $throwable ) {
				$this->log(
					'PirateShip notification email failed',
					array(
						'order_id' => $order->get_id(),
						'error'    => $throwable->getMessage(),
					)
				);
			}
		}
	}

	/**
	 * Find the cheapest plan for one package across carrier services.
	 *
	 * When $service_code is non-empty only services that can rate that code
	 * are considered and the plan is requested for that exact service, so the
	 * stored plan matches what the customer selected at checkout instead of
	 * silently mixing carriers or services.
	 *
	 * @param array     $carrier_services Enabled carrier services.
	 * @param \WC_Order $order            The order.
	 * @param array     $package          Packed package data.
	 * @param int       $package_number   1-based package number.
	 * @param string    $service_code     Chosen service code, or '' for cheapest.
	 * @return array Best plan or empty array.
	 */
	protected function find_best_plan( array $carrier_services, \WC_Order $order, array $package, int $package_number, string $service_code ): array {
		$best_plan = array();
		$best_cost = PHP_FLOAT_MAX;

		foreach ( $carrier_services as $carrier_svc ) {
			if ( '' !== $service_code && ! $carrier_svc->supports_service_code( $service_code ) ) {
				continue;
			}

			$candidate_plan = $carrier_svc->build_package_plan( $order, $package, $package_number, $service_code );

			if ( ! empty( $candidate_plan ) && (float) $candidate_plan['rate_amount'] < $best_cost ) {
				$best_plan = $candidate_plan;
				$best_cost = (float) $candidate_plan['rate_amount'];
			}
		}

		return $best_plan;
	}

	/**
	 * Extract the checkout-selected service from the order's shipping items.
	 *
	 * Shipping_Method::calculate_shipping() stores the rated service identity
	 * in the rate meta_data and WooCommerce persists it onto the order's
	 * shipping item, so it survives from checkout to order processing.
	 *
	 * @param \WC_Order $order The order.
	 * @return array {
	 *     service_code: string  The selected service code ('' when unknown).
	 *     is_optimizer_method: bool Whether the order shipped via this plugin.
	 *     method_label: string The shipping method label the customer saw.
	 * }
	 */
	protected function get_chosen_shipping_info( \WC_Order $order ): array {
		$info = array(
			'service_code'        => '',
			'is_optimizer_method' => false,
			'method_label'        => '',
		);

		foreach ( $order->get_shipping_methods() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Shipping ) {
				continue;
			}

			if ( ! str_starts_with( (string) $item->get_method_id(), 'fk_usps_optimizer' ) ) {
				continue;
			}

			$info['is_optimizer_method'] = true;
			$info['method_label']        = (string) $item->get_name();
			$info['service_code']        = (string) $item->get_meta( self::META_SERVICE_CODE );
			break;
		}

		return $info;
	}

	/**
	 * Handle the "Test Connection" AJAX action from the settings page.
	 *
	 * Verifies the nonce, determines which carrier to test from the POSTed
	 * carrier value (falling back to the saved setting), uses credentials
	 * POSTed from the current form (so the test works before saving), and
	 * returns the result as a JSON response so the settings page can display
	 * it inline without a full page reload.
	 *
	 * @return void
	 */
	public function handle_test_connection_ajax(): void {
		check_ajax_referer( 'fk_usps_test_connection', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You do not have permission to perform this action.', 'fk-usps-optimizer' ) ),
				403
			);
			return;
		}

		// Prefer the carrier from the POST request (current dropdown value) so
		// the test reflects the UI even before settings are saved.
		$posted_carrier = sanitize_text_field( wp_unslash( $_POST['carrier'] ?? '' ) );
		$carrier        = in_array( $posted_carrier, array( 'shipengine', 'shipstation' ), true )
			? $posted_carrier
			: $this->settings->get_carrier();

		if ( 'shipstation' === $carrier ) {
			$api_key    = sanitize_text_field( wp_unslash( $_POST['shipstation_api_key'] ?? '' ) );
			$api_secret = sanitize_text_field( wp_unslash( $_POST['shipstation_api_secret'] ?? '' ) );
			$result     = $this->shipstation_service->test_connection( $api_key, $api_secret );
		} else {
			$api_key    = sanitize_text_field( wp_unslash( $_POST['shipengine_api_key'] ?? '' ) );
			$carrier_id = sanitize_text_field( wp_unslash( $_POST['shipengine_carrier_id'] ?? '' ) );
			$result     = $this->shipengine_service->test_connection( $api_key, $carrier_id );
		}

		wp_send_json_success( $result );
	}

	/**
	 * Register the plugin's shipping method with WooCommerce.
	 *
	 * @param array $methods Registered shipping method classes.
	 * @return array Updated shipping methods.
	 */
	public function register_shipping_method( array $methods ): array {
		$methods['fk_usps_optimizer'] = '\FK_USPS_Optimizer\Shipping_Method';
		return $methods;
	}

	/**
	 * Append estimated delivery date on a separate line in the cart/checkout
	 * shipping label.
	 *
	 * WooCommerce sanitises the rate label, stripping HTML. This filter runs
	 * after sanitisation and its output is rendered through wp_kses_post(),
	 * which allows <br> tags.
	 *
	 * @param string            $label  The full shipping method label (name + price).
	 * @param \WC_Shipping_Rate $method The shipping rate object.
	 * @return string Modified label with delivery date on a new line.
	 */
	public function append_delivery_date_to_label( string $label, $method ): string {
		if ( 'fk_usps_optimizer' !== $method->get_method_id() ) {
			return $label;
		}

		$meta = $method->get_meta_data();

		if ( ! empty( $meta['est_delivery_display'] ) ) {
			$label .= '<br>' . esc_html( $meta['est_delivery_display'] );
		}

		return $label;
	}

	/**
	 * Get the packing service instance.
	 *
	 * @return Packing_Service
	 */
	public function get_packing_service(): Packing_Service {
		return $this->packing_service;
	}

	/**
	 * Get the plugin settings instance.
	 *
	 * @return Settings
	 */
	public function get_settings(): Settings {
		return $this->settings;
	}

	/**
	 * Return the carrier service selected in settings.
	 *
	 * Returns the first enabled carrier service for backward compatibility.
	 *
	 * @return ShipEngine_Service|ShipStation_Service Active carrier service.
	 */
	public function get_carrier_service() {
		if ( 'shipstation' === $this->settings->get_carrier() ) {
			return $this->shipstation_service;
		}

		return $this->shipengine_service;
	}

	/**
	 * Return all carrier services enabled in settings.
	 *
	 * When ShipStation is enabled and multiple carrier+service pairs are
	 * configured, one ShipStation_Service instance is created per pair so
	 * that rates from all pairs (e.g. UPS + USPS) are compared.
	 * The primary pair uses the singleton instance; additional pairs get
	 * new instances with carrier/service code overrides.
	 *
	 * @return array<ShipEngine_Service|ShipStation_Service> Active carrier services.
	 */
	public function get_carrier_services(): array {
		$carriers = $this->settings->get_carriers();
		$services = array();

		foreach ( $carriers as $carrier ) {
			if ( 'shipengine' === $carrier ) {
				$services[] = $this->shipengine_service;
			} elseif ( 'shipstation' === $carrier ) {
				$pairs = $this->settings->get_shipstation_service_pairs();

				if ( empty( $pairs ) ) {
					// No pairs configured; use the default singleton.
					$services[] = $this->shipstation_service;
					continue;
				}

				// Group pairs by carrier_code so we can issue one API call per
				// carrier instead of one per (carrier, service) pair.  When a
				// carrier has multiple configured services we ask the API for
				// "all services" (empty service_code) and filter the response
				// to the configured services via the allow-list.
				$grouped = array();
				foreach ( $pairs as $pair ) {
					$carrier_code = (string) ( $pair['carrier_code'] ?? '' );
					$service_code = (string) ( $pair['service_code'] ?? '' );

					if ( '' === $carrier_code ) {
						continue;
					}

					if ( ! isset( $grouped[ $carrier_code ] ) ) {
						$grouped[ $carrier_code ] = array();
					}

					if ( ! in_array( $service_code, $grouped[ $carrier_code ], true ) ) {
						$grouped[ $carrier_code ][] = $service_code;
					}
				}

				$is_primary_used = false;

				foreach ( $grouped as $carrier_code => $service_codes ) {
					$has_all_services = in_array( '', $service_codes, true );
					$specific_codes   = array_values(
						array_filter(
							$service_codes,
							static function ( string $code ): bool {
								return '' !== $code;
							}
						)
					);

					// If the admin configured "all services" for this carrier,
					// drop any specific codes — the wildcard supersedes them.
					if ( $has_all_services ) {
						$effective_service_code = '';
						$allow_list             = null;
					} elseif ( count( $specific_codes ) === 1 ) {
						// Single specific service: keep the explicit code so
						// the API request is as narrow as possible.
						$effective_service_code = $specific_codes[0];
						$allow_list             = null;
					} else {
						// Multiple specific services: ask for all and filter.
						$effective_service_code = '';
						$allow_list             = $specific_codes;
					}

					// Reuse the singleton for the first carrier that matches
					// its configured carrier code; spin up new instances for
					// the rest.  This keeps existing test/mock seams working.
					$primary_carrier = $this->settings->get_shipstation_carrier_code();
					$primary_service = $this->settings->get_shipstation_service_code();

					if ( ! $is_primary_used
						&& $carrier_code === $primary_carrier
						&& $effective_service_code === $primary_service
						&& null === $allow_list
					) {
						$services[]      = $this->shipstation_service;
						$is_primary_used = true;
						continue;
					}

					$services[] = new ShipStation_Service(
						$this->settings,
						$carrier_code,
						$effective_service_code,
						$allow_list
					);
				}
			}
		}

		// Fallback to ShipEngine if nothing enabled.
		return ! empty( $services ) ? $services : array( $this->shipengine_service );
	}

	/**
	 * Build a human-readable order note summarizing the shipping plan.
	 *
	 * @param array $plan Shipping plan data.
	 * @return string Formatted note text.
	 */
	protected function build_package_note( array $plan ): string {
		$lines   = array();
		$lines[] = __( 'USPS Shipping Plan', 'fk-usps-optimizer' );
		$lines[] = sprintf(
			/* translators: 1: number of packages, 2: currency symbol and total rate. */
			__( 'Total: %1$d package(s), $%2$s', 'fk-usps-optimizer' ),
			(int) ( $plan['total_package_count'] ?? 0 ),
			number_format( (float) ( $plan['total_rate_amount'] ?? 0 ), 2 )
		);

		foreach ( $plan['packages'] ?? array() as $package ) {
			$lines[] = '';
			$lines[] = sprintf(
				/* translators: 1: package number, 2: package name, 3: mode. */
				__( 'Package %1$d: %2$s (%3$s)', 'fk-usps-optimizer' ),
				(int) $package['package_number'],
				$package['package_name'],
				$package['mode']
			);

			if ( ! empty( $package['service_label'] ) ) {
				$lines[] = sprintf(
					/* translators: %s shipping service label (e.g., "USPS Priority Mail", "UPS Ground"). */
					__( 'Service: %s', 'fk-usps-optimizer' ),
					$package['service_label']
				);
			}

			$lines[] = sprintf(
				/* translators: %s rate amount. */
				__( 'Rate: $%s', 'fk-usps-optimizer' ),
				number_format( (float) $package['rate_amount'], 2 )
			);
			$lines[] = sprintf(
				/* translators: 1: length, 2: width, 3: height. */
				__( 'Dims: %1$s x %2$s x %3$s in', 'fk-usps-optimizer' ),
				$package['dimensions']['length'],
				$package['dimensions']['width'],
				$package['dimensions']['height']
			);
			$lines[] = sprintf(
				/* translators: %s weight in ounces. */
				__( 'Weight: %s oz', 'fk-usps-optimizer' ),
				$package['weight_oz']
			);

			if ( ! empty( $package['cubic_tier'] ) ) {
				$lines[] = sprintf(
					/* translators: %s cubic tier value. */
					__( 'Cubic Tier: %s', 'fk-usps-optimizer' ),
					$package['cubic_tier']
				);
			}

			if ( ! empty( $package['packing_list'] ) ) {
				$lines[] = __( 'Items:', 'fk-usps-optimizer' ) . ' ' . implode( ', ', $package['packing_list'] );
			}
		}

		return implode( "\n", $lines );
	}

	/**
	 * Store the rendered packing-plan note text on the order as private
	 * meta so it can be displayed in the admin metabox and injected into
	 * the WooCommerce REST API response (which is how PirateShip receives
	 * it). The order's stored `customer_note` column is intentionally left
	 * untouched so the plan cannot leak into customer-facing surfaces.
	 *
	 * Idempotent: each call overwrites any previously stored value.
	 *
	 * As a one-time migration for orders processed by earlier versions of
	 * this plugin, any legacy `<!-- fk-pack-start --> ... <!-- fk-pack-end -->`
	 * block found in the existing customer note is stripped and the
	 * cleaned customer note is written back.
	 *
	 * @param \WC_Order $order Order to update.
	 * @param array     $plan  Shipping plan data.
	 * @return void
	 */
	protected function store_packing_plan_note( \WC_Order $order, array $plan ): void {
		$note_text = $this->build_package_note( $plan );

		$order->update_meta_data( self::PACKING_NOTE_META_KEY, $note_text );

		// Migrate legacy data: if a previous version persisted the plan
		// inside the customer-note column wrapped in marker comments,
		// strip it now so the column holds only the customer-entered text.
		$existing = (string) $order->get_customer_note( 'edit' );
		if ( '' !== $existing && false !== strpos( $existing, self::PACKING_NOTE_START_MARKER ) ) {
			$cleaned = $this->strip_packing_plan_block( $existing );
			if ( $cleaned !== $existing ) {
				$order->set_customer_note( $cleaned );
			}
		}

		$order->save();
	}

	/**
	 * Filter callback for `woocommerce_rest_prepare_shop_order_object` that
	 * appends the stored packing-plan note text to the response's
	 * `customer_note` field so PirateShip and other REST consumers receive
	 * the plan alongside the order.
	 *
	 * The plan is appended to (not substituted for) any customer-entered
	 * note. If the setting is disabled or no plan is stored, the response
	 * is returned unchanged.
	 *
	 * @param mixed           $response Response object (typically
	 *                                  \WP_REST_Response).
	 * @param \WC_Order|mixed $order    Order object being serialised.
	 * @param mixed           $request  Originating REST request
	 *                                  (unused).
	 * @return mixed The (possibly modified) response.
	 */
	public function inject_packing_plan_into_rest_response( $response, $order, $request = null ) {
		unset( $request );

		if ( ! $this->settings->is_add_packing_to_customer_note_enabled() ) {
			return $response;
		}

		if ( ! $order instanceof \WC_Order ) {
			return $response;
		}

		if ( ! is_object( $response ) || ! isset( $response->data ) || ! is_array( $response->data ) ) {
			return $response;
		}

		$note_text = (string) $order->get_meta( self::PACKING_NOTE_META_KEY, true );
		if ( '' === trim( $note_text ) ) {
			return $response;
		}

		$existing_note = isset( $response->data['customer_note'] ) ? (string) $response->data['customer_note'] : '';

		$response->data['customer_note'] = '' === trim( $existing_note )
			? $note_text
			: rtrim( $existing_note ) . "\n\n" . $note_text;

		return $response;
	}

	/**
	 * Remove a legacy `<!-- fk-pack-start --> ... <!-- fk-pack-end -->`
	 * block from a string and tidy up the surrounding whitespace.
	 *
	 * Retained so we can clean customer-note values written by earlier
	 * versions of the plugin; new code does not produce these markers.
	 *
	 * @param string $value Source string.
	 * @return string String with the block removed.
	 */
	protected function strip_packing_plan_block( string $value ): string {
		if ( '' === $value || false === strpos( $value, self::PACKING_NOTE_START_MARKER ) ) {
			return $value;
		}

		$pattern = '/\s*' . preg_quote( self::PACKING_NOTE_START_MARKER, '/' )
			. '.*?' . preg_quote( self::PACKING_NOTE_END_MARKER, '/' ) . '\s*/s';

		$stripped = preg_replace( $pattern, '', $value );

		if ( null === $stripped ) {
			// On regex failure, fall back to the original value rather than
			// nuking the customer note.
			return $value;
		}

		return trim( $stripped );
	}

	/**
	 * Log a debug message via the WooCommerce logger.
	 *
	 * @param string $message Log message.
	 * @param array  $context Additional context.
	 * @return void
	 */
	protected function log( string $message, array $context = array() ): void {
		if ( ! $this->settings->is_debug_logging_enabled() ) {
			return;
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( $message . ' ' . wp_json_encode( $context ), array( 'source' => 'fk-usps-optimizer' ) );
		}
	}
}
